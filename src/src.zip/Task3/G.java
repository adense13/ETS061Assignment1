package Task3;
public class G {
	public static final int ARRIVAL = 1, READY = 2, MEASURE = 3, ARRIVAL_2 = 4, READY_2 = 5, MEASURE_2 = 6;
	public static double time = 0;
	//he
}