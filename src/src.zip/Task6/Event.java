package inl�mning1task6;

public class Event {
	public double eventTime;
	public int eventType;
	public Event next;
}
