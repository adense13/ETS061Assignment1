package Task2;
class Event {
	public double eventTime;
	public int eventType;
	public Event next;
}