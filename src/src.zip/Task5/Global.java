package inl�mning1task5;

public class Global{
	public static final int ARRIVAL = 1, READY = 2, MEASURE = 3, ARRIVALDISPATCHER = 4, READYDISPATCHER = 5;;
	public static double time = 0;
}
