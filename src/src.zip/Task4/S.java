package Task4;

public class S {
	public static final int ARRIVAL = 1;
	public static final int READY = 3;
	public static final int MEASUREMENT = 5;
	
	public static double time = 0;
}
